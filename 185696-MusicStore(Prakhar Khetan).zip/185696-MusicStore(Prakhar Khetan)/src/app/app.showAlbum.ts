import { Component, OnInit } from "@angular/core";
import { AlbumService } from './app.albumservice';
@Component({
    selector:'show-Album',
    templateUrl:'showAlbum.html'
})
export class ShowAlbumComponent implements OnInit{
    constructor(private myservice:AlbumService){}
    albumAll:any[]=[];

    ngOnInit(){
       this.albumAll=this.myservice.getAllAlbum();      //to recieve all the data stored in array
    }

    delete(data:number):any{
        this.albumAll.splice(data,1);   //To delete the data
        alert("Are you sure you want to Delete?");
    }


}
