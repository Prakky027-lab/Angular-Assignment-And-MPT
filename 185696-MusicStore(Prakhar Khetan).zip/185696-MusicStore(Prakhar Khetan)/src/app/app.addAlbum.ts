import {Component} from '@angular/core';
import { AlbumService } from "./app.albumservice";
import { Router } from "@angular/router";
@Component({
    selector:'add-album',
    templateUrl:'addAlbum.html'
})
export class AddAlbumComponent{
    constructor(private service:AlbumService, private router:Router){} //Creating constructor
    albumId:number;
    albumTitle:string;
    albumArtist:string;
    albumPrice:number;
    albumAll:any[]=[];
    addData:any;
    add():any{
        this.addData=({albumId:this.albumId,albumTitle:this.albumTitle,albumArtist:this.albumArtist,albumPrice:this.albumPrice});   
        if(this.service.addAlbum(this.addData)){
            this.router.navigate(['show']);
        }
    }
}
