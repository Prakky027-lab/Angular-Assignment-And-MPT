import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn:'root'
})
export class AlbumService{
    constructor(private http:HttpClient){}

    albumAll:any[]=[]
    //To store the data input by user
    addAlbum(data:any){
        this.albumAll.push(data);  
        return true;
    }

    //To display the data
    getAllAlbum(){
        return this.albumAll;
     }
}