﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {AddAlbumComponent} from './app.addAlbum';
import {ShowAlbumComponent}from './app.showAlbum'
import{ FormsModule} from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
const routes:Routes=[
    {path:'',component:ShowAlbumComponent}, //will directly navigate to 'show' link ie to ShowAlbumComponent as the application is loaded}
    {path:'add',component:AddAlbumComponent}, // to navigate to AddAlbumComponent to add album details-->  
    {path:'show',component:ShowAlbumComponent}, // to navigate to ShowAlbumComponent to show album details-->  

    ];
    

@NgModule({            
    imports: [
        BrowserModule,FormsModule,RouterModule.forRoot(routes),HttpClientModule,FormsModule
        
        
    ],
    declarations: [
        AppComponent,AddAlbumComponent,ShowAlbumComponent,      //Declaration of different classes used in program.
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }